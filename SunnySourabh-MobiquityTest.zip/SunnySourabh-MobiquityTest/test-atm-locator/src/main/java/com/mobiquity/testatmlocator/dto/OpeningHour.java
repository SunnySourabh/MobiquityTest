package com.mobiquity.testatmlocator.dto;

import java.util.ArrayList;
import java.util.List;

public class OpeningHour{

	String dayOfWeek;
	List<Hours> hours= new ArrayList<Hours>();
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public List<Hours> getHours() {
		return hours;
	}
	public void setHours(List<Hours> hours) {
		this.hours = hours;
	}
}