package com.mobiquity.testatmlocator.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobiquity.testatmlocator.dto.Atm;

@Service
public class AtmLocatorService {

	@Autowired
	RestTemplate restTemplate;
	
	public AtmLocatorService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
	public Atm[] locateAllAtms() throws JsonMappingException, JsonProcessingException{
		String json = getJson();
		ObjectMapper mapper = new ObjectMapper();
		Atm[] atms = mapper.readValue(json, Atm[].class);
		return atms;
	}
	
	public List<Atm> locateAtmByCity(String city) throws JsonMappingException, JsonProcessingException{
		List<Atm> atmsByCity = new ArrayList<>();
		String json = getJson();
		ObjectMapper mapper = new ObjectMapper();
		Atm[] atms = mapper.readValue(json, Atm[].class);
		if(atms != null && atms.length > 0) {
			for(Atm atm : atms) {
				if(city.equals(atm.getAddress().getCity())) {
					atmsByCity.add(atm);
				}
			}
		}
		
		return atmsByCity;
	}
	
	private String getJson() {
		String str = restTemplate.getForObject("https://www.ing.nl/api/locator/atms/", String.class);
		str = str.substring(str.indexOf("[{\"address\""));
		return str;
	}
}
