package com.mobiquity.testatmlocator.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mobiquity.testatmlocator.dto.Atm;
import com.mobiquity.testatmlocator.service.AtmLocatorService;

@RestController
@RequestMapping("/locate")
public class AtmLocatorController {

	@Autowired
	AtmLocatorService atmLocatorService;
	
	public AtmLocatorController() {
		
	}
	
	public AtmLocatorController(AtmLocatorService atmLocatorService) {
		this.atmLocatorService = atmLocatorService;
	}
	
	@GetMapping("/atm")
	public ResponseEntity<Object> locateAllAtms() throws JsonMappingException, JsonProcessingException{
		Atm[] atms= atmLocatorService.locateAllAtms();
		if(atms != null && atms.length > 0) {
			return new ResponseEntity<>(
				      atms, 
				      HttpStatus.OK);
		}else {
			return new ResponseEntity<>(
				      "No ATM available", 
				      HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/atm/{city}")
	public ResponseEntity<Object> locateAtmByCity(@PathVariable(name="city") String city) throws JsonMappingException, JsonProcessingException{
		List<Atm> atmsByCity = new ArrayList<>();
		if(city != null && !city.trim().isEmpty()) {
			atmsByCity = atmLocatorService.locateAtmByCity(city.trim());
			if(atmsByCity.size() > 0) {
				return new ResponseEntity<>(
						atmsByCity, 
					      HttpStatus.OK);
			}else {
				return new ResponseEntity<>(
					      "No ATM found for the given city", 
					      HttpStatus.NOT_FOUND);
			}
		}else {
			return new ResponseEntity<Object>(
				      "Please provide any city name", 
				      HttpStatus.NOT_FOUND);
		}
	}
}
