package com.mobiquity.testatmlocator.dto;

import java.util.ArrayList;
import java.util.List;

public class DaysOfWeeks {

	String dayOfWeek;
	List<Hours> hoursList = new ArrayList<>();
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public List<Hours> getHoursList() {
		return hoursList;
	}
	public void setHoursList(List<Hours> hoursList) {
		this.hoursList = hoursList;
	}
}
