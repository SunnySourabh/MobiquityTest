package com.mobiquity.testatmlocator.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class AtmLocatorServiceTest {
	
	private AtmLocatorService service;
	private RestTemplate template;
	
	@BeforeEach
	public void setup() {
		template = new RestTemplate();
		service = new AtmLocatorService(template);
	}
	
	@Test
	public void locateAllAtms() throws JsonMappingException, JsonProcessingException {
		assertEquals(3117, service.locateAllAtms().length);
		System.out.println();
	}
	
	@Test
	public void locateAtmByCity() throws JsonMappingException, JsonProcessingException {
		String city = "Capelle aan den IJssel";
		assertNotNull(service.locateAtmByCity(city),"Null");
		assertEquals(10, service.locateAtmByCity(city).size());
	}
}
