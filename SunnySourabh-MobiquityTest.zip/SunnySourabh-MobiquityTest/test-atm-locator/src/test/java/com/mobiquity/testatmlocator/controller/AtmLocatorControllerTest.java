package com.mobiquity.testatmlocator.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mobiquity.testatmlocator.service.AtmLocatorService;

public class AtmLocatorControllerTest {
	
	private AtmLocatorController controller;
	private AtmLocatorService service;
	private RestTemplate template;
	
	@BeforeEach
	public void setup() {
		template = new RestTemplate();
		service = new AtmLocatorService(template);
		controller = new AtmLocatorController(service);
	}
	
	@Test
	public void locateAllAtms() throws JsonMappingException, JsonProcessingException {
		controller.locateAllAtms();
	}
	
	@Test
	public void locateAtmByCity() throws JsonMappingException, JsonProcessingException {
		String city = "Capelle aan den IJssel";
		controller.locateAtmByCity(city);
	}
}
